module.exports = {
  plugins: {
    autoprefixer: {}
  }
};
