<template>
  <div>
    <!-- <div class="header">header</div>
    <div class="navbar">左侧</div>
    <div class="main">右侧主区域</div>-->
    <!-- 头部区域 -->
    <app-header />
    <!-- 左侧导航区域 -->
    <app-navbar />
    <!-- 右侧主区域 -->
    <app-main />
  </div>
</template>
<script>
import AppHeader from "./AppHeader";
import AppNavbar from "./AppNavbar";
import AppMain from "./AppMain";
export default {
  components: {
    AppHeader,
    AppNavbar,
    AppMain
  }
};
</script>
<style>
/* header */
.header {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  background-color: #2d3a4b;
  padding: 0;
  line-height: 50px;
}
/* left */
.navbar {
  position: absolute;
  width: 200px;
  top: 50px;
  left: 0;
  bottom: 0;
  background-color: #545c64;
}
/* right */
.main {
  position: absolute;
  top: 50px;
  left: 200px;
  right: 0;
  bottom: 0;
  padding: 10px;
  /* background-color: pink; */
}
</style>