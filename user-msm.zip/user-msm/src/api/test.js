import request from "@/utils/request";

export default {
    getList() {
        const req = request({
            url: '/db.json',
            method: 'get'
        })
        return req
    }
}