<template >
  <div>
    <h1>欢迎访问会员管理系统</h1>
  </div>
</template>
<style scoped>
div {
  text-align: center;
}
</style>
