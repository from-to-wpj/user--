<template>
  <div id="app">
    <!-- 组件出口 -->
    <router-view />
  </div>
</template>

<style lang="scss">

body{
  font-family: "微软雅黑";
   overflow: hidden;
   margin: 0;
   
}
</style>
